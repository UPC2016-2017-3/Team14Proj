create database ocss
go
use ocss
/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     2014/3/12 9:56:19                            */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('v_Score')
            and   type = 'V')
   drop view v_Score
go

if exists (select 1
            from  sysobjects
           where  id = object_id('v_Teaching')
            and   type = 'V')
   drop view v_Teaching
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Course')
            and   type = 'U')
   drop table Course
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Elective')
            and   type = 'U')
   drop table Elective
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Notice')
            and   type = 'U')
   drop table Notice
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Student')
            and   type = 'U')
   drop table Student
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Teacher')
            and   type = 'U')
   drop table Teacher
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Teaching')
            and   type = 'U')
   drop table Teaching
go

/*==============================================================*/
/* Table: Course                                                */
/*==============================================================*/
create table Course (
   CID                  int                  identity,
   Description          nvarchar(Max)        null,
   Grade                nvarchar(10)         null,
   Term                 nvarchar(10)         null,
   Credit               int                  null,
   CName                nvarchar(20)         null,
   constraint PK_COURSE primary key (CID)
)
go

/*==============================================================*/
/* Table: Elective                                              */
/*==============================================================*/
create table Elective (
   EID                  int                  identity,
   SID                  int                  null,
   CID                  int                  null,
   Score                float                null,
   constraint PK_ELECTIVE primary key (EID)
)
go

/*==============================================================*/
/* Table: Notice                                                */
/*==============================================================*/
create table Notice (
   NID                  int                  identity,
   NTitle               nvarchar(100)        null,
   NContent             nvarchar(max)        null,
   NAuthor              nvarchar(20)         null,
   NTime                datetime             null default getdate(),
   constraint PK_NOTICE primary key (NID)
)
go

/*==============================================================*/
/* Table: Student                                               */
/*==============================================================*/
create table Student (
   SID                  int                  identity,
   SNo                  char(9)              null,
   SName                nvarchar(8)          null,
   SPwd                 varchar(20)          null,
   SSex                 nchar(1)             null,
   SClass               varchar(10)          null,
   SType                varchar(10)          null,
   SDepartment          nvarchar(20)         null,
   SMajor               nvarchar(20)         null,
   SMaxNum              int                  null,
   SActualNum           int                  null,
   SBirthday            datetime             null,
   SInTime              datetime             null,
   SGrade               nvarchar(10)         null,
   SNote                nvarchar(100)        null,
   constraint PK_STUDENT primary key (SID)
)
go

/*==============================================================*/
/* Table: Teacher                                               */
/*==============================================================*/
create table Teacher (
   TID                  int                  identity,
   TNo                  char(4)              null,
   TName                nvarchar(8)          null,
   TSex                 nchar(1)             null,
   TMajor               nvarchar(20)         null,
   TPwd                 nvarchar(20)         null,
   TDepartment          nvarchar(20)         null,
   TTitle               nvarchar(10)         null,
   TIsAdmin             int                  null default 0,
   constraint PK_TEACHER primary key (TID)
)
go

/*==============================================================*/
/* Table: Teaching                                              */
/*==============================================================*/
create table Teaching (
   ID                   int                  identity,
   TID                  int                  null,
   CID                  int                  null,
   Week                 nvarchar(20)         null,
   Timeperiod           nvarchar(20)         null,
   Place                nvarchar(20)         null,
   MaxNum               int                  null,
   ActualNum            int                  null default 0,
   constraint PK_TEACHING primary key (ID)
)
go

/*==============================================================*/
/* View: v_Score                                                */
/*==============================================================*/
create view v_Score as
SELECT     dbo.Student.SID, dbo.Student.SNo, dbo.Student.SName, dbo.Course.CID, dbo.Course.Credit, dbo.Course.CName, dbo.Teaching.Week, dbo.Teaching.Timeperiod, 
                      dbo.Teaching.Place, dbo.Teaching.MaxNum, dbo.Teaching.ActualNum, dbo.Elective.Score, dbo.Elective.EID
FROM         dbo.Course INNER JOIN
                      dbo.Elective ON dbo.Course.CID = dbo.Elective.CID INNER JOIN
                      dbo.Student ON dbo.Elective.SID = dbo.Student.SID INNER JOIN
                      dbo.Teaching ON dbo.Course.CID = dbo.Teaching.CID INNER JOIN
                      dbo.Teacher ON dbo.Teaching.TID = dbo.Teacher.TID
go

/*==============================================================*/
/* View: v_Teaching                                             */
/*==============================================================*/
create view v_Teaching as
SELECT     dbo.Student.SID, dbo.Student.SNo, dbo.Student.SName, dbo.Course.CID, dbo.Course.Credit, dbo.Course.CName, dbo.Teaching.Week, dbo.Teaching.Timeperiod, 
                      dbo.Teaching.Place, dbo.Teaching.MaxNum, dbo.Teaching.ActualNum, dbo.Elective.Score
FROM         dbo.Course INNER JOIN
                      dbo.Elective ON dbo.Course.CID = dbo.Elective.CID INNER JOIN
                      dbo.Student ON dbo.Elective.SID = dbo.Student.SID INNER JOIN
                      dbo.Teaching ON dbo.Course.CID = dbo.Teaching.CID INNER JOIN
                      dbo.Teacher ON dbo.Teaching.TID = dbo.Teacher.TID
go


SET IDENTITY_INSERT [Course] ON

INSERT [Course] ([CID],[CName],[Grade],[Term],[Credit],[Description]) VALUES ( 1,N'����',N'����',N'��һѧ��',5,N'����')
INSERT [Course] ([CID],[CName],[Grade],[Term],[Credit],[Description]) VALUES ( 2,N'��Ӱ',N'���',N'�ڶ�ѧ��',5,N'��Ӱ')
INSERT [Course] ([CID],[CName],[Grade],[Term],[Credit],[Description]) VALUES ( 3,N'��ѧ',N'��һ',N'��һѧ��',10,N'��ѧ')

SET IDENTITY_INSERT [Course] OFF

SET IDENTITY_INSERT [Elective] ON

INSERT [Elective] ([EID],[SID],[CID],[Score]) VALUES ( 2,1,1,100)
INSERT [Elective] ([EID],[SID],[CID]) VALUES ( 4,1,2)
INSERT [Elective] ([EID],[SID],[CID],[Score]) VALUES ( 5,1,3,90)

SET IDENTITY_INSERT [Elective] OFF


SET IDENTITY_INSERT [Notice] ON

INSERT [Notice] ([NID],[NTitle],[NContent],[NAuthor],[NTime]) VALUES ( 1,N'���ǲ���.Net��ѵ����JQuery Mobile+PhoneGap�ֻ������γ�',N'�ƶ�������Ŀǰ��һ���ȵ㣬2013��������ǲ�����.net��ѵ�γ��м�����Unity3d��Ϸ�����γ̣���������ǲ��Ϳ���Unity3d��Ϸ������.Net����Android����γ̡�����һ��������˴�����Unity3d����ʦ���ڹ���������Unity3dѧϰ���ȳ���',N'��ѧ��',N'2014/2/23 16:56:03')
INSERT [Notice] ([NID],[NTitle],[NContent],[NAuthor],[NTime]) VALUES ( 2,N'2014��3��8��1000��IT������Ƹ��',N'Ϊ���õ��ƽ�IT�˲���Դ���г����ú;�ҵ������������ҵ���и߶������˲ŵ����������йش��������Ա���ϴ��ǲ��ͽ������ţ���2014��3��8�գ��������ٰ�ITר����Ƹ�ᡣ���������Ϊ����������ҹ��������յĻ�����ô�������μӱ��Ρ�ITר����Ƹ�ᡱ��',N'��ҵ��',N'2014/2/23 16:56:44')

SET IDENTITY_INSERT [Notice] OFF

SET IDENTITY_INSERT [Student] ON

INSERT [Student] ([SID],[SNo],[SName],[SPwd],[SSex],[SClass],[SType],[SDepartment],[SMajor],[SMaxNum],[SActualNum],[SBirthday],[SInTime],[SGrade]) VALUES ( 1,N'02220301',N'С��',N'123',N'Ů',N'һ��',N'����',N'����ϵ',N'������Ϣ����',20,3,N'1983/1/1 0:00:00',N'2014/3/10 0:00:00',N'��һ')

SET IDENTITY_INSERT [Student] OFF

SET IDENTITY_INSERT [Teacher] ON

INSERT [Teacher] ([TID],[TNo],[TName],[TPwd],[TIsAdmin]) VALUES ( 1,N'0001',N'admin',N'123',1)
INSERT [Teacher] ([TID],[TNo],[TName],[TSex],[TMajor],[TPwd],[TDepartment],[TTitle],[TIsAdmin]) VALUES ( 2,N'0002',N'���п�',N'��',N'����',N'123',N'������ʲôϵ',N'����',0)
INSERT [Teacher] ([TID],[TNo],[TName],[TSex],[TMajor],[TPwd],[TDepartment],[TTitle],[TIsAdmin]) VALUES ( 3,N'0003',N'�ܲ�',N'��',N'������Ϣ����',N'123',N'����ϵ',N'������',0)

SET IDENTITY_INSERT [Teacher] OFF

SET IDENTITY_INSERT [Teaching] ON

INSERT [Teaching] ([ID],[TID],[CID],[Week],[Timeperiod],[Place],[MaxNum],[ActualNum]) VALUES ( 1,2,1,N'����һ',N'����1��2��',N'���103',100,1)
INSERT [Teaching] ([ID],[TID],[CID],[Week],[Timeperiod],[Place],[MaxNum],[ActualNum]) VALUES ( 6,3,2,N'������',N'����1��2��',N'���',100,1)
INSERT [Teaching] ([ID],[TID],[CID],[Week],[Timeperiod],[Place],[MaxNum],[ActualNum]) VALUES ( 7,3,3,N'������',N'����3��4��',N'��²²�',100,0)
INSERT [Teaching] ([ID],[TID],[CID],[Week],[Timeperiod],[Place],[MaxNum],[ActualNum]) VALUES ( 8,2,3,N'������',N'����1��2��',N'һ��303',100,1)

SET IDENTITY_INSERT [Teaching] OFF