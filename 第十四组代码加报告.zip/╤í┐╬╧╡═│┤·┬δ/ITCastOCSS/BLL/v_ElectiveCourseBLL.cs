﻿using System;
using System.Data;
using System.Collections.Generic;
using ITCastOCSS.Model;
namespace ITCastOCSS.BLL
{
    /// <summary>
    /// v_ElectiveCourseBLL
    /// </summary>
    public partial class v_ElectiveCourseBLL
    {
        private readonly ITCastOCSS.DAL.v_ElectiveCourseDAL dal = new ITCastOCSS.DAL.v_ElectiveCourseDAL();
        public v_ElectiveCourseBLL()
        { }
        #region  BasicMethod
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public ITCastOCSS.Model.v_ElectiveCourse GetModel(int SID, string SNo, string SName, string SPwd, string SSex, string SClass, string SType, string SDepartmentSDepartment, string SMajor, int SMaxNum, int SActualNum, DateTime SBirthday, DateTime SInTime, string SGrade, string SNote, int EID, decimal Score, int CID, string CName, string Week, string Timeperiod, string Place, int MaxNum, int ActualNum, string Description)
        {

            return dal.GetModel(SID, SNo, SName, SPwd, SSex, SClass, SType, SDepartmentSDepartment, SMajor, SMaxNum, SActualNum, SBirthday, SInTime, SGrade, SNote, EID, Score, CID, CName, Week, Timeperiod, Place, MaxNum, ActualNum, Description);
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            return dal.GetList(strWhere);
        }
        /// <summary>
        /// 获得前几行数据
        /// </summary>
        public DataSet GetList(int Top, string strWhere, string filedOrder)
        {
            return dal.GetList(Top, strWhere, filedOrder);
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public List<ITCastOCSS.Model.v_ElectiveCourse> GetModelList(string strWhere)
        {
            DataSet ds = dal.GetList(strWhere);
            return DataTableToList(ds.Tables[0]);
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public List<ITCastOCSS.Model.v_ElectiveCourse> DataTableToList(DataTable dt)
        {
            List<ITCastOCSS.Model.v_ElectiveCourse> modelList = new List<ITCastOCSS.Model.v_ElectiveCourse>();
            int rowsCount = dt.Rows.Count;
            if (rowsCount > 0)
            {
                ITCastOCSS.Model.v_ElectiveCourse model;
                for (int n = 0; n < rowsCount; n++)
                {
                    model = dal.DataRowToModel(dt.Rows[n]);
                    if (model != null)
                    {
                        modelList.Add(model);
                    }
                }
            }
            return modelList;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetAllList()
        {
            return GetList("");
        }

        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            return dal.GetRecordCount(strWhere);
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            return dal.GetListByPage(strWhere, orderby, startIndex, endIndex);
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        //public DataSet GetList(int PageSize,int PageIndex,string strWhere)
        //{
        //return dal.GetList(PageSize,PageIndex,strWhere);
        //}

        #endregion  BasicMethod
        #region  ExtensionMethod
        public List<v_ElectiveCourse> GetElectiveCourse(int sid)
        {
            return GetModelList(" sid="+sid);
        }
        #endregion  ExtensionMethod
    }
}

