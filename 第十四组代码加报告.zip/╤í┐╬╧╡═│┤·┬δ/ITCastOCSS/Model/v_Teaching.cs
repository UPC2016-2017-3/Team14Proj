﻿/**  版本信息模板在安装目录下，可自行修改。
* v_Teaching.cs
*
* 功 能： N/A
* 类 名： v_Teaching
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/3/3 20:36:21   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：动软卓越（北京）科技有限公司　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
namespace ITCastOCSS.Model
{
	/// <summary>
	/// v_Teaching:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class v_Teaching
	{
		public v_Teaching()
		{}
		#region Model
		private int _cid;
		private string _cname;
		private int? _credit;
		private string _term;
		private string _grade;
		private int _id;
		private int _tid;
		private string _tno;
		private string _tname;
		private string _week;
		private string _timeperiod;
		private string _place;
		private int? _maxnum;
		private int? _actualnum;
		/// <summary>
		/// 
		/// </summary>
		public int CID
		{
			set{ _cid=value;}
			get{return _cid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string CName
		{
			set{ _cname=value;}
			get{return _cname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Credit
		{
			set{ _credit=value;}
			get{return _credit;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Term
		{
			set{ _term=value;}
			get{return _term;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Grade
		{
			set{ _grade=value;}
			get{return _grade;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int ID
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int TID
		{
			set{ _tid=value;}
			get{return _tid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TNo
		{
			set{ _tno=value;}
			get{return _tno;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TName
		{
			set{ _tname=value;}
			get{return _tname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Week
		{
			set{ _week=value;}
			get{return _week;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Timeperiod
		{
			set{ _timeperiod=value;}
			get{return _timeperiod;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Place
		{
			set{ _place=value;}
			get{return _place;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? MaxNum
		{
			set{ _maxnum=value;}
			get{return _maxnum;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? ActualNum
		{
			set{ _actualnum=value;}
			get{return _actualnum;}
		}
		#endregion Model

	}
}

