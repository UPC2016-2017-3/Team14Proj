﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Maticsoft.Common")]
[assembly: AssemblyDescription("Common Library By Maticsoft")]
[assembly: AssemblyConfiguration("Maticsoft")]
[assembly: AssemblyCompany("动软卓越（北京）科技有限公司")]
[assembly: AssemblyProduct("Maticsoft.Common")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	
[assembly: AssemblyVersion("3.5.0")]	
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
