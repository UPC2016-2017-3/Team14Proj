﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ITCastOCSS.BLL;
using ITCastOCSS.Model;
namespace Web.UserControl
{
    public partial class SideBar : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string no = txtNo.Text;
            string pwd = txtPwd.Text;
            string code = txtCode.Text;

            if (string.IsNullOrEmpty(no))
            {
                lblMsg.Text = "请输入登录账号";
                txtNo.Focus();
                return;
            }
            if (string.IsNullOrEmpty(pwd))
            {
                lblMsg.Text = "请输入密码";
                txtPwd.Focus();
                return;
            }
            if (string.IsNullOrEmpty(code))
            {
                lblMsg.Text = "请输入验证码";
                txtCode.Focus();
                return;
            }
            if (Session["code"] != null && Session["code"].ToString().ToLower() == code.ToLower())
            {
                Session.Remove("code");
                string type = ddlType.SelectedValue;
                //学生
                if (type == "1")
                {
                    StudentBLL bll = new StudentBLL();
                    ITCastOCSS.Model.Student stu;
                    if (bll.Login(no, pwd, out stu))
                    {
                        Session["user"] = stu;
                        Response.Redirect("student/index.aspx");
                    }
                    else
                    {
                        lblMsg.Text = "登录失败";
                    }
                }
                else if (type == "2")
                {
                    TeacherBLL bll = new TeacherBLL();
                    ITCastOCSS.Model.Teacher tea;
                    if (bll.Login(no, pwd, out tea))
                    {
                        Session["user"] = tea;
                        //管理员
                        if (tea.TIsAdmin == 1)
                        {
                            Response.Redirect("admin/index.aspx");
                        }
                        //教师
                        else if (tea.TIsAdmin == 0)
                        {
                            Response.Redirect("teacher/index.aspx");
                        }
                    }
                    else
                    {
                        lblMsg.Text = "登录失败";
                    }
                }
            }
            else {
                lblMsg.Text = "验证码错误";
            }
           
            

        }
    }
}