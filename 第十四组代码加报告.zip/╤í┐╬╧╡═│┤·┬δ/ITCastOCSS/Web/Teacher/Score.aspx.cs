﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Teacher
{
    public partial class Score : System.Web.UI.Page
    {
        ITCastOCSS.Model.Teacher teacher;
        protected void Page_Load(object sender, EventArgs e)
        {
            teacher = Session["user"] as ITCastOCSS.Model.Teacher;
            if (teacher == null)
            {
                Response.Redirect("~/index.aspx");
            }
        }

        //录入成绩
        protected void btnSelect_Click(object sender, EventArgs e)
        {
            ITCastOCSS.BLL.v_ScoreBLL bll = new ITCastOCSS.BLL.v_ScoreBLL();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                Label lbl = GridView1.Rows[i].Cells[0].FindControl("lblID") as Label;

                TextBox txt = GridView1.Rows[i].Cells[4].FindControl("txt") as TextBox;
                if (!string.IsNullOrEmpty(txt.Text))
                {
                    bll.Input(int.Parse(lbl.Text), double.Parse(txt.Text));
                }
            }
            this.DataBind();
            lblMsg.Text = "成绩录入成功";
        }
    }
}