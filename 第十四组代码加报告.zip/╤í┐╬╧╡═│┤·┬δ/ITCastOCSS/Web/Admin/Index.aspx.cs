﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Admin
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //排课
        protected void btn_Click(object sender, EventArgs e)
        {
            ITCastOCSS.BLL.TeachingBLL bll = new ITCastOCSS.BLL.TeachingBLL();

            ITCastOCSS.Model.Teaching model = new ITCastOCSS.Model.Teaching();
            model.CID = int.Parse(ddlCourse.SelectedValue);
            model.TID = int.Parse(ddlTeacher.SelectedValue);
            model.ActualNum = 0;
            model.MaxNum = int.Parse(txtMax.Text);
            model.Place = txtPlace.Text;
            model.Timeperiod = ddlTimePeriod.Text;
            model.Week = ddlWeek.Text;
           
            if (bll.Add(model) > 0)
            {
                this.DataBind();
            }
            else
            {
                Response.Write("<script>alert('排课失败');</script>");
            }
        }
    }
}