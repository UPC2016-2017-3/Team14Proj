﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Student
{
    public partial class SelectedCourse : Pagebase
    {
        //ITCastOCSS.Model.Student student;
        protected void Page_Load(object sender, EventArgs e)
        {
            //student = Session["user"] as ITCastOCSS.Model.Student;
            //if (student == null)
            //{
            //    Response.Redirect("~/index.aspx");
            //}
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            ITCastOCSS.BLL.StudentBLL bll = new ITCastOCSS.BLL.StudentBLL();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                CheckBox chk = GridView1.Rows[i].Cells[7].FindControl("chk") as CheckBox;
                Label lblId = GridView1.Rows[i].Cells[0].FindControl("lblID") as Label;
                //获取课程id
                int cid = int.Parse(lblId.Text);
                int sid = student.SID;
                string cname = GridView1.Rows[i].Cells[2].Text;
                if (chk.Checked)
                {
                    if (bll.UnSelect(sid, cid))
                    {
                        lblMsg.Text += cname + " 亲，您真不学了<br>";
                    }
                    else
                    {
                        lblMsg.Text += cname + " 亲，退选失败了哦<br>";
                    }
                }

            }
            GridView1.DataBind();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if(e.Row.RowType == DataControlRowType.DataRow)
            {
                string t  = e.Row.Cells[3].Text;
                int score;
                if (!int.TryParse(t,out score))
                {
                    e.Row.Cells[3].Text = "成绩未录入";
                }
            }
        }
    }
}