﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web.Student
{
    public class Pagebase:System.Web.UI.Page
    {
        protected ITCastOCSS.Model.Student student;
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            student = Session["user"] as ITCastOCSS.Model.Student;
            if (student == null)
            {
                Response.Redirect("~/Index.aspx");
            }
        }
    }
}