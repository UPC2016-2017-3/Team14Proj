﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Student
{
    public partial class OnlineCourse : Pagebase
    {
        //ITCastOCSS.Model.Student student;
        protected void Page_Load(object sender, EventArgs e)
        {
            //student = Session["user"] as ITCastOCSS.Model.Student;
            //if (student == null)
            //{
            //    Response.Redirect("~/index.aspx");
            //}
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            ITCastOCSS.BLL.StudentBLL bll = new ITCastOCSS.BLL.StudentBLL();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                CheckBox chk = GridView1.Rows[i].Cells[8].FindControl("chk") as CheckBox;
                Label lblCId = GridView1.Rows[i].Cells[0].FindControl("lblCID") as Label;
                Label lblId = GridView1.Rows[i].Cells[1].FindControl("lblID") as Label;
                //获取课程id
                int cid = int.Parse(lblCId.Text);
                //排课表的id，要更新排课表中的选课人数
                int id = int.Parse(lblId.Text);
                int sid = student.SID;
                string cname = GridView1.Rows[i].Cells[1].Text;
                if (chk.Checked)
                {
                     //-2 已选该课程 -1 课已被选完，1 选课成功   0选课失败
                    int flag = bll.Select(sid, cid,id);
                    if (flag == -1)
                    {
                        lblMsg.Text += cname + " 亲，课程已被选完<br>";
                    }
                    else if (flag == -2)
                    {
                        lblMsg.Text += cname + " 亲，您已选该课程<br>";
                    }
                    else if (flag > 0)
                    {
                        lblMsg.Text += cname + " 亲，选择成功，别忘了去上课哦<br>";
                    }
                    else
                    {
                        lblMsg.Text += cname + " 亲，选课失败<br>";
                    }

                }

            }
            GridView1.DataBind();
        }
    }
}