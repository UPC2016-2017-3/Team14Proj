﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Student
{
    public partial class ChangePwd : Pagebase
    {
        //ITCastOCSS.Model.Student student;
        protected void Page_Load(object sender, EventArgs e)
        {
            //student = Session["user"] as ITCastOCSS.Model.Student;
            //if (student == null)
            //{
            //    Response.Redirect("~/index.aspx");
            //}

            txtName.Text = base.student.SNo;
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            string no = txtName.Text;
            string oldPwd = txtPwd.Text;
            string confirm = txtConfirmPwd.Text;
            string newPwd = txtNewPwd.Text;
            if (string.IsNullOrEmpty(oldPwd))
            {
                lblMsg.Text = "请输入账号";
                txtPwd.Focus();
                return;
            }

            if (oldPwd != confirm)
            {
                lblMsg.Text = "两次密码不一致，请重新输入";
                txtPwd.Focus();
                return;
            }
            if (string.IsNullOrEmpty(newPwd))
            {
                lblMsg.Text = "请输入账号";
                txtNewPwd.Focus();
                return;
            }

            ITCastOCSS.BLL.StudentBLL bll = new ITCastOCSS.BLL.StudentBLL();
            if (bll.ChangePwd(no, oldPwd, newPwd))
            {
                lblMsg.Text = "密码修改成功";
            }
            else
            {
                lblMsg.Text = "密码修改失败";
            }

        }
    }
}